package Formularios;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class Abertura extends JFrame {

    JLabel lbl_titulo = new JLabel("Programação de Computadores");
    JButton btn_Calculo = new JButton("Abrir Calculo");
    JButton btn_Sair = new JButton("Sair");

    public Abertura() {
        initComponents();
    }

    void initComponents() {
        setTitle("Abertura");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(360, 220);
        setLocationRelativeTo(null);
        setLayout(null);

        lbl_titulo.setBounds(80, 30, 220, 25);
        btn_Calculo.setBounds(100, 80, 150, 30);
        btn_Sair.setBounds(100, 125, 150, 30);
        add(lbl_titulo);
        add(btn_Calculo);
        add(btn_Sair);

        btn_Calculo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_CalculoActionPerformed(evt);
            }
        });
        btn_Sair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_SairActionPerformed(evt);
            }
        });
    }

    // Abre o formulário Calculo e fecha este
    private void btn_CalculoActionPerformed(java.awt.event.ActionEvent evt) {
        Calculo frame2 = new Calculo();

        frame2.setVisible(true);
        dispose();
    }

    private void btn_SairActionPerformed(java.awt.event.ActionEvent evt) {
        System.exit(0);
    }
}
