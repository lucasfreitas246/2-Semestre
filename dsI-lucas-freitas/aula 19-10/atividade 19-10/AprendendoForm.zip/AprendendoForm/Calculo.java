package Formularios;

import java.awt.Color;
import java.awt.Font;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class Calculo extends JFrame {

    JPanel jPanel1 = new JPanel();
    JLabel jLabel1 = new JLabel("N1");
    JLabel jLabel2 = new JLabel("N2");
    JLabel jLabel3 = new JLabel("Resultado");
    JTextField txt_n1 = new JTextField();
    JTextField txt_n2 = new JTextField();
    JTextField txt_res = new JTextField();
    JButton btn_Soma = new JButton("+");
    JButton btn_Subtracao = new JButton("-");
    JButton btn_Multiplicacao = new JButton("*");
    JButton btn_Divisao = new JButton("/");
    JButton btn_Retornar = new JButton("Retornar");
    JButton btn_Novo = new JButton("Novo");
    JButton btn_Limpar = new JButton("Limpar");
    JButton btn_Sair = new JButton("Sair");
    JButton btn_Comparacao = new JButton("Comparacao");

    public Calculo() {
        initComponents();
        Desabilitar();
    }

    void initComponents() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);
        setSize(600, 440);
        setLocationRelativeTo(null);

        // Painel com borda com título
        jPanel1.setLayout(null);
        jPanel1.setBackground(new Color(204, 204, 51));
        jPanel1.setBorder(BorderFactory.createTitledBorder(null, "Programação de Computadores",
                javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION,
                javax.swing.border.TitledBorder.DEFAULT_POSITION,
                new Font("Tahoma", Font.BOLD | Font.ITALIC, 14)));
        jPanel1.setBounds(0, 0, 590, 410);
        add(jPanel1);

        // Rótulos
        jLabel1.setBounds(90, 90, 60, 20);
        jLabel2.setBounds(90, 120, 60, 20);
        jLabel3.setBounds(60, 175, 80, 20);
        jPanel1.add(jLabel1);
        jPanel1.add(jLabel2);
        jPanel1.add(jLabel3);

        // Campos de texto
        txt_n1.setBounds(150, 90, 230, 22);
        txt_n2.setBounds(150, 120, 230, 22);
        txt_res.setBounds(160, 175, 220, 22);
        jPanel1.add(txt_n1);
        jPanel1.add(txt_n2);
        jPanel1.add(txt_res);

        // Botões de cima
        btn_Soma.setBounds(60, 280, 50, 25);
        btn_Subtracao.setBounds(130, 280, 50, 25);
        btn_Multiplicacao.setBounds(200, 280, 50, 25);
        btn_Divisao.setBounds(270, 280, 50, 25);
        btn_Retornar.setBounds(350, 280, 90, 25);
        jPanel1.add(btn_Soma);
        jPanel1.add(btn_Subtracao);
        jPanel1.add(btn_Multiplicacao);
        jPanel1.add(btn_Divisao);
        jPanel1.add(btn_Retornar);

        // Botões de baixo
        btn_Novo.setBounds(60, 320, 80, 25);
        btn_Limpar.setBounds(170, 320, 80, 25);
        btn_Sair.setBounds(280, 320, 80, 25);
        btn_Comparacao.setBounds(380, 320, 110, 25);
        jPanel1.add(btn_Novo);
        jPanel1.add(btn_Limpar);
        jPanel1.add(btn_Sair);
        jPanel1.add(btn_Comparacao);

        btn_Soma.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_SomaActionPerformed(evt);
            }
        });
        btn_Subtracao.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_SubtracaoActionPerformed(evt);
            }
        });
        btn_Multiplicacao.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_MultiplicacaoActionPerformed(evt);
            }
        });
        btn_Divisao.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_DivisaoActionPerformed(evt);
            }
        });
        btn_Retornar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_RetornarActionPerformed(evt);
            }
        });
        btn_Novo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_NovoActionPerformed(evt);
            }
        });
        btn_Limpar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_LimparActionPerformed(evt);
            }
        });
        btn_Sair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_SairActionPerformed(evt);
            }
        });
    }

    void Desabilitar() {
        txt_n1.setEditable(false);
        txt_n2.setEditable(false);
        txt_res.setEditable(false);
    }

    void Habilitar() {
        txt_n1.setEditable(true);
        txt_n2.setEditable(true);
        txt_res.setEditable(true);
    }

    private void btn_SomaActionPerformed(java.awt.event.ActionEvent evt) {
        int x, y, z; // Variáveis de apoio
        String r;    // R string para receber valor

        x = Integer.parseInt(txt_n1.getText()); // Mesclando o campo com a variável
        y = Integer.parseInt(txt_n2.getText());

        z = x + y; // operação
        r = String.valueOf(z); // passando a variável para String para que o campo de texto seja aceito
        txt_res.setText(r); // Campo de resposta recebendo valor
    }

    private void btn_SubtracaoActionPerformed(java.awt.event.ActionEvent evt) {
        int x, y, z;
        String r;

        x = Integer.parseInt(txt_n1.getText());
        y = Integer.parseInt(txt_n2.getText());

        z = x - y;
        r = String.valueOf(z);
        txt_res.setText(r);
    }

    private void btn_MultiplicacaoActionPerformed(java.awt.event.ActionEvent evt) {
        int x, y, z;
        String r;

        x = Integer.parseInt(txt_n1.getText());
        y = Integer.parseInt(txt_n2.getText());

        z = x * y;
        r = String.valueOf(z);
        txt_res.setText(r);
    }

    private void btn_DivisaoActionPerformed(java.awt.event.ActionEvent evt) {
        int x, y, z;
        String r;

        x = Integer.parseInt(txt_n1.getText());
        y = Integer.parseInt(txt_n2.getText());

        z = x / y;
        r = String.valueOf(z);
        txt_res.setText(r);
    }

    private void btn_NovoActionPerformed(java.awt.event.ActionEvent evt) {
        Habilitar();
    }

    private void btn_LimparActionPerformed(java.awt.event.ActionEvent evt) {
        txt_n1.setText("");
        txt_n2.setText("");
        txt_res.setText("");
    }

    private void btn_SairActionPerformed(java.awt.event.ActionEvent evt) {
        System.exit(0);
    }

    private void btn_RetornarActionPerformed(java.awt.event.ActionEvent evt) {
        Abertura frame1 = new Abertura();

        frame1.setVisible(true);
        dispose();
    }
}
