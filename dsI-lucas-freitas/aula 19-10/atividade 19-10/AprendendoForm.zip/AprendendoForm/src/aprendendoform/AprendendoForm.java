package aprendendoform;

import Formularios.Abertura;

public class AprendendoForm {

    public static void main(String[] args) {
        Abertura inicio = new Abertura();
        inicio.setVisible(true);
    }
}
